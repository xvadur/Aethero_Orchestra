import React from 'react';

export default function AgentsChatLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

import fs from 'fs';
import path from 'path';

const MEMORY_LOG_DIR = path.join(process.cwd(), 'src/data/memoryLogs');

export async function logMemoryToFile(
  threadId: string,
  agentName: string,
  content: string
): Promise<void> {
  const filePath = path.join(MEMORY_LOG_DIR, `${threadId}.json`);

  if (!fs.existsSync(MEMORY_LOG_DIR)) {
    fs.mkdirSync(MEMORY_LOG_DIR, { recursive: true });
  }

  const logEntry = { agentName, content, timestamp: Date.now() };

  if (fs.existsSync(filePath)) {
    const existingLogs = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    existingLogs.push(logEntry);
    fs.writeFileSync(filePath, JSON.stringify(existingLogs, null, 2));
  } else {
    fs.writeFileSync(filePath, JSON.stringify([logEntry], null, 2));
  }
}

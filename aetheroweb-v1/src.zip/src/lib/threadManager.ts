// src/lib/threadManager.ts
import fs from 'fs';
import path from 'path';

export interface Message {
  role: 'user' | 'agent' | 'assistant';
  agentName?: string;
  content: string;
  timestamp?: number;
}

const THREAD_PREFIX = 'aeth_chat_thread_';
const THREADS_DIR = path.join(process.cwd(), 'src/data/threads');

export async function createNewThreadId(): Promise<string> {
  const threadId = `${THREAD_PREFIX}${Date.now()}`;
  localStorage.setItem(threadId, JSON.stringify([]));
  return threadId;
}

export async function saveMessagesToThread(threadId: string, messages: Message[]): Promise<void> {
  if (!threadId || !threadId.startsWith(THREAD_PREFIX)) return;
  try {
    localStorage.setItem(threadId, JSON.stringify(messages));
  } catch (error) {
    console.error('Failed to save messages to localStorage:', error);
  }
}

export async function getMessagesForThread(threadId: string): Promise<Message[]> {
  if (!threadId || !threadId.startsWith(THREAD_PREFIX)) return [];
  try {
    const data = localStorage.getItem(threadId);
    return data ? (JSON.parse(data) as Message[]) : [];
  } catch (error) {
    console.error('Failed to retrieve or parse messages from localStorage:', error);
    return [];
  }
}

export async function getAllThreadIds(): Promise<string[]> {
  const threadIds: string[] = [];
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.startsWith(THREAD_PREFIX)) {
      threadIds.push(key);
    }
  }
  return threadIds;
}

export function formatThreadForExport(threadId: string, messages: Message[]): string {
  const title = threadId.replace(THREAD_PREFIX, '');
  const markdownContent = messages
    .map(
      (msg) =>
        `### ${msg.role === 'user' ? 'User Input' : (msg.agentName || 'Agent Response')}` +
        `\n${msg.content}\n`
    )
    .join('\n---\n\n');
  return `# Chat Thread Log: ${title}\n\n${markdownContent}`;
}

export async function saveThreadToFile(threadId: string, messages: Message[]): Promise<void> {
  const filePath = path.join(THREADS_DIR, `${threadId}.json`);
  const threadData = { id: threadId, messages };

  if (!fs.existsSync(THREADS_DIR)) {
    fs.mkdirSync(THREADS_DIR, { recursive: true });
  }

  fs.writeFileSync(filePath, JSON.stringify(threadData, null, 2));
}

export async function loadThreadFromFile(threadId: string): Promise<{ id: string; messages: Message[] } | null> {
  const filePath = path.join(THREADS_DIR, `${threadId}.json`);

  if (fs.existsSync(filePath)) {
    const threadData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    return threadData;
  }

  return null;
}

export async function getAllThreadIdsFromFile(): Promise<string[]> {
  if (!fs.existsSync(THREADS_DIR)) {
    return [];
  }

  return fs.readdirSync(THREADS_DIR).map((fileName) => fileName.replace('.json', ''));
}
